KUMRAT ENGLISH — ANDROID SOURCE + CLOUD BUILD WORKFLOW

This is Android project source, NOT an APK yet. It includes a GitHub Actions workflow to build a debug APK in the cloud, so a computer is not required for the build itself.

Mobile-only build outline:
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this ZIP to the repository (make sure the .github/workflows/android-apk.yml file is included).
3. Open the repository's Actions tab. If prompted, enable workflows.
4. Run "Build Kumrat English APK" using Run workflow, or push/upload the files to the main branch to trigger it.
5. Wait for the workflow to finish successfully. Open the completed run and download the artifact named "Kumrat-English-debug-apk".
6. Extract the artifact ZIP on your phone and install app-debug.apk. Android may ask you to allow installs from that browser/file manager.

Important:
- The APK is not built until GitHub Actions completes successfully.
- Speech recognition depends on the phone having a compatible speech-recognition service and internet may be required by that service.
- This is an early prototype with sample lessons, not a full AI tutor or complete curriculum.
- The debug APK is for testing, not Play Store release.
